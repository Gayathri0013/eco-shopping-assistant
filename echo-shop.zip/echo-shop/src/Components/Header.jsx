import { Link } from "react-router-dom";

function Header() {
  return (
    <nav
      style={{
        display: "flex",
        justifyContent: "flex-end",
        alignItems: "center",
        background: "rgba(0, 0, 0, 0.7)", // Semi-transparent black background
        padding: "15px 40px",
        position: "sticky",
        top: 0,
        zIndex: 1000, // Ensure navbar is on top
        width: "100vw", // Full viewport width
        boxSizing: "border-box",
      }}
    >
      <Link to="/clothes" className="nav-link" style={{ color: "#fff", marginLeft: 30, fontWeight: "bold", textDecoration: "none" }}>
        Clothes
      </Link>
      <Link to="/home-living" className="nav-link" style={{ color: "#fff", marginLeft: 30, fontWeight: "bold", textDecoration: "none" }}>
        Home & Living
      </Link>
      <Link to="/accessories-beauty" className="nav-link" style={{ color: "#fff", marginLeft: 30, fontWeight: "bold", textDecoration: "none" }}>
        Accessories & Beauty
      </Link>
      <Link to="/account" className="nav-link" style={{ color: "#fff", marginLeft: 30, fontWeight: "bold", textDecoration: "none" }}>
        Account
      </Link>
      <Link to="/cart" className="nav-link" style={{ color: "#fff", marginLeft: 30, fontWeight: "bold", textDecoration: "none" }}>
        Cart
      </Link>
      <Link to="/orders" className="nav-link" style={{ color: "#fff", marginLeft: 30, fontWeight: "bold", textDecoration: "none" }}>
        Orders
      </Link>
    </nav>
  );
}

export default Header;
