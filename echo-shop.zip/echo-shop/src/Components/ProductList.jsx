function ProductList({ products }) {
  return (
    <ul className="product-list">
      {products.map((product, idx) => (
        <li key={idx} className="product-item">{product}</li>
      ))}
    </ul>
  );
}
export default ProductList;
