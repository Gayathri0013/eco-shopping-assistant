function Footer() {
  return (
    <footer className="site-footer">
      <p>© 2025 Eco Shop. All rights reserved.</p>
    </footer>
  );
}
export default Footer;
