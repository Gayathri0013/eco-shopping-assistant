import React from "react";
import { Outlet } from "react-router-dom";
import Header from "./Header";

function Layout() {
  return (
    <>
      <Header />
      <main
        style={{
          padding: "20px",
          maxWidth: "1100px",
          margin: "auto",
          minHeight: "calc(100vh - 70px)", // Adjust height minus navbar height
          boxSizing: "border-box",
        }}
      >
        <Outlet />
      </main>
    </>
  );
}

export default Layout;
