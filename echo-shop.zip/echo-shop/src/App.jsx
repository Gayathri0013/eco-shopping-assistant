import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { useState } from "react";
import './App.css';


import Layout from "./components/Layout";
import Home from "./pages/Home";
import Account from "./pages/Account";
import Clothes from "./pages/Clothes";
import HomeLiving from "./pages/HomeLiving";
import AccessoriesBeauty from "./pages/AccessoriesBeauty";
import Cart from "./pages/Cart";
import Orders from "./pages/Orders";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  function PrivateRoute({ children }) {
    return isLoggedIn ? children : <Navigate to="/account" />;
  }

  return (
    <Router>
      <Routes>
        {/* Account page without navbar */}
        <Route path="/account" element={<Account setIsLoggedIn={setIsLoggedIn} />} />

        {/* Protected pages wrapped in Layout for navbar */}
        <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
          <Route index element={<Home />} />
          <Route path="home" element={<Home />} />
          <Route path="clothes" element={<Clothes />} />
          <Route path="home-living" element={<HomeLiving />} />
          <Route path="accessories-beauty" element={<AccessoriesBeauty />} />
          <Route path="cart" element={<Cart />} />
          <Route path="orders" element={<Orders />} />
        </Route>

        {/* Redirect any unknown paths to login */}
        <Route path="*" element={<Navigate to="/account" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
