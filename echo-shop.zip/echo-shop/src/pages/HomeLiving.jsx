function HomeLiving() {
  const products = [
    "Durable, eco-friendly cutting board made from sustainably harvested bamboo.",
    "Comfortable pillow crafted with organic cotton and natural dyes.",
    "Stylish vase made from 100% recycled glass, perfect for any décor.",
    "Eco-friendly and biodegradable rug made from natural jute fibers.",
    "Decorative lampshade crafted from recycled paper materials.",
    "Reusable utensils made from sustainable bamboo, perfect for daily use.",
    "Lightweight curtains made from organic linen fabric for eco-friendly homes.",
    "Elegant candle holder crafted from recycled metal materials.",
  ];

  return (
    <div style={{ padding: 20, color: '#333', fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }}>
      <h2>Home & Living</h2>
      <ul>
        {products.map((item, index) => (
          <li key={index} style={{ marginBottom: 8, fontSize: 16 }}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

export default HomeLiving;
