function AccessoriesBeauty() {
  const products = [
    "Cleansers and moisturizers made with all-natural ingredients.",
    "Handcrafted accessories made from recycled metals and sustainable materials.",
    "Sustainable makeup brushes with bamboo handles and soft bristles.",
    "Moisturizing lip balm made with organic beeswax and natural oils.",
    "Durable tote bag crafted from recycled fabric for everyday use.",
    "Eco-friendly hair brush with sustainably sourced wooden handle.",
    "Stylish sunglasses made from recycled plastic materials.",
    "Lightweight serum formulated with organic botanical extracts.",
  ];

  return (
    <div style={{ padding: 20, color: '#333', fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }}>
      <h2>Accessories & Beauty</h2>
      <ul>
        {products.map((item, index) => (
          <li key={index} style={{ marginBottom: 8, fontSize: 16 }}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

export default AccessoriesBeauty;
