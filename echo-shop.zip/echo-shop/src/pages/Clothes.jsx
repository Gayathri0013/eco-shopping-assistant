function Clothes() {
  const products = [
    "Soft, breathable, and made from 100% organic cotton.",
    "Lightweight jacket made from recycled plastic bottles.",
    "Eco-friendly bamboo fabric dress with a stylish design.",
    "Durable and sustainable backpack made from hemp fibers.",
    "Warm sweater made with ethically sourced organic wool.",
    "Stylish jeans crafted from recycled denim fabric.",
    "Breathable and sustainable shirt made from organic linen.",
    "Sneakers made with natural and recycled materials.",
  ];

  return (
    <div style={{ padding: 20, color: '#333', fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }}>
      <h2>Clothes</h2>
      <ul>
        {products.map((item, index) => (
          <li key={index} style={{ marginBottom: 8, fontSize: 16 }}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

export default Clothes;
