function Cart() {
  return (
    <div style={{
      padding: 20,
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      color: '#333',
      maxWidth: 900,
      margin: 'auto',
    }}>
      <h2>Cart</h2>
      <p>Your cart items will be displayed here.</p>
      {/* You can add detailed cart item lists and checkout buttons here as per requirement */}
    </div>
  );
}

export default Cart;
