import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Account({ setIsLoggedIn }) {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("login");
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [signupName, setSignupName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupConfirmPassword, setSignupConfirmPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [signupError, setSignupError] = useState("");

  const activateLogin = () => {
    setActiveTab("login");
    setLoginError("");
    setSignupError("");
  };

  const activateSignup = () => {
    setActiveTab("signup");
    setLoginError("");
    setSignupError("");
  };

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    setLoginError("");
    if (!loginEmail || !loginPassword) {
      setLoginError("Please fill all login fields.");
      return;
    }
    // Simulate successful login
    alert(`Logged in as ${loginEmail}`);
    setIsLoggedIn(true);
    navigate("/home");
  };

  const handleSignupSubmit = (e) => {
    e.preventDefault();
    setSignupError("");
    if (!signupName || !signupEmail || !signupPassword || !signupConfirmPassword) {
      setSignupError("Please fill out all fields.");
      return;
    }
    if (signupPassword !== signupConfirmPassword) {
      setSignupError("Passwords do not match.");
      return;
    }
    if (signupPassword.length < 6) {
      setSignupError("Password must be at least 6 characters.");
      return;
    }
    alert(`Account created for ${signupName}`);
    activateLogin();
  };

  return (
    <div className="account-flex-center">
      <div className="account-container" role="main">
        <svg
          className="leaf-icon"
          viewBox="0 0 64 64"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden="true"
          focusable="false"
        >
          <path d="M32 12c-15 7-21 24-18 34 8-8 20-13 34-13 12 0 17 3 17 3C59 24 47 15 32 12zm0 0c12 3 27 13 27 37a4 4 0 0 1-4 4c-21 0-46-2-46-4C9 25 23 15 32 12z" />
        </svg>
        <h1 className="account-title">Welcome to Eco Shopping Assistant</h1>
        <div className="subtitle">Make sustainable choices &amp; track your eco impact</div>
        <div className="tab-btns">
          <button
            type="button"
            className={`tab-btn ${activeTab === "login" ? "active" : ""}`}
            onClick={activateLogin}
          >
            Login
          </button>
          <button
            type="button"
            className={`tab-btn ${activeTab === "signup" ? "active" : ""}`}
            onClick={activateSignup}
          >
            Sign Up
          </button>
        </div>

        <form
          onSubmit={handleLoginSubmit}
          className={activeTab === "login" ? "active" : ""}
          aria-label="Login form"
          noValidate
        >
          <label htmlFor="login-email">Email</label>
          <input
            type="email"
            id="login-email"
            name="login-email"
            required
            placeholder="you@email.com"
            value={loginEmail}
            onChange={(e) => setLoginEmail(e.target.value)}
          />
          <label htmlFor="login-password">Password</label>
          <input
            type="password"
            id="login-password"
            name="login-password"
            required
            placeholder="Your password"
            value={loginPassword}
            onChange={(e) => setLoginPassword(e.target.value)}
          />
          <div className="error-msg">{loginError}</div>
          <input type="submit" value="Log In" />
          <div className="form-footer">Forgot your password?</div>
        </form>

        <form
          onSubmit={handleSignupSubmit}
          className={activeTab === "signup" ? "active" : ""}
          aria-label="Sign up form"
          noValidate
        >
          <label htmlFor="signup-name">Full Name</label>
          <input
            type="text"
            id="signup-name"
            name="signup-name"
            required
            placeholder="Your full name"
            value={signupName}
            onChange={(e) => setSignupName(e.target.value)}
          />
          <label htmlFor="signup-email">Email</label>
          <input
            type="email"
            id="signup-email"
            name="signup-email"
            required
            placeholder="you@email.com"
            value={signupEmail}
            onChange={(e) => setSignupEmail(e.target.value)}
          />
          <label htmlFor="signup-password">Password</label>
          <input
            type="password"
            id="signup-password"
            name="signup-password"
            required
            placeholder="Choose a password"
            value={signupPassword}
            onChange={(e) => setSignupPassword(e.target.value)}
          />
          <label htmlFor="signup-confirm-password">Confirm Password</label>
          <input
            type="password"
            id="signup-confirm-password"
            name="signup-confirm-password"
            required
            placeholder="Confirm password"
            value={signupConfirmPassword}
            onChange={(e) => setSignupConfirmPassword(e.target.value)}
          />
          <div className="error-msg">{signupError}</div>
          <input type="submit" value="Create Account" />
          <div className="form-footer">
            Already an eco shopper?{" "}
            <span
              role="button"
              tabIndex={0}
              style={{ color: "#388e3c", cursor: "pointer" }}
              onClick={activateLogin}
              onKeyPress={activateLogin}
            >
              Log in
            </span>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Account;
