import { Link } from "react-router-dom";

function Home() {
  return (
    <div
      style={{
        paddingTop: "70px", // space for sticky navbar height (approx)
        maxWidth: "1100px",
        margin: "auto",
        paddingLeft: "20px",
        paddingRight: "20px",
        color: "#000",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      }}
    >
      <header style={{ textAlign: "center", maxWidth: "900px", marginBottom: "40px" }}>
        <h1 style={{ fontSize: "3rem", marginBottom: 10 }}>Eco Shopping Assistant</h1>
        <p style={{ fontSize: "1.2rem", margin: 0 }}>
          Your sustainable guide to eco-friendly shopping
        </p>
      </header>

      <section
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: "30px",
          maxWidth: "1100px",
          margin: "auto",
        }}
      >
        <Link
          to="/clothes"
          style={{ textDecoration: "none", color: "inherit", display: "block" }}
        >
          <div
            style={{
              background: "rgba(255, 255, 255, 0.1)",
              borderRadius: "20px",
              padding: "30px",
              textAlign: "center",
              backdropFilter: "blur(6px)",
              boxShadow: "0 8px 20px rgba(0, 0, 0, 0.3)",
              transition: "transform 0.3s ease, box-shadow 0.3s ease",
              cursor: "pointer",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "translateY(-10px)";
              e.currentTarget.style.boxShadow = "0 12px 25px rgba(0, 0, 0, 0.5)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "none";
              e.currentTarget.style.boxShadow = "0 8px 20px rgba(0, 0, 0, 0.3)";
            }}
          >
            <img
              src="https://omnitail.net/wp-content/uploads/2021/06/amazon-clothes-sm.png"
              alt="Sustainable Clothes"
              style={{
                width: "100%",
                maxHeight: 180,
                objectFit: "cover",
                borderRadius: 15,
                marginBottom: 15,
              }}
            />
            <h2 style={{ marginBottom: 15, fontSize: "1.8rem" }}>Clothes</h2>
            <p style={{ fontSize: "1rem", lineHeight: 1.5 }}>
              Discover sustainable fashion made with organic fabrics and ethical production practices.
            </p>
          </div>
        </Link>

        <Link
          to="/home-living"
          style={{ textDecoration: "none", color: "inherit", display: "block" }}
        >
          <div
            style={{
              background: "rgba(255, 255, 255, 0.1)",
              borderRadius: "20px",
              padding: "30px",
              textAlign: "center",
              backdropFilter: "blur(6px)",
              boxShadow: "0 8px 20px rgba(0, 0, 0, 0.3)",
              transition: "transform 0.3s ease, box-shadow 0.3s ease",
              cursor: "pointer",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "translateY(-10px)";
              e.currentTarget.style.boxShadow = "0 12px 25px rgba(0, 0, 0, 0.5)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "none";
              e.currentTarget.style.boxShadow = "0 8px 20px rgba(0, 0, 0, 0.3)";
            }}
          >
            <img
              src="https://paintedcreativity.com/wp-content/uploads/2024/02/Eco-friendly-home_decor.webp"
              alt="Eco Home & Living"
              style={{
                width: "100%",
                maxHeight: 180,
                objectFit: "cover",
                borderRadius: 15,
                marginBottom: 15,
              }}
            />
            <h2 style={{ marginBottom: 15, fontSize: "1.8rem" }}>Home & Living</h2>
            <p style={{ fontSize: "1rem", lineHeight: 1.5 }}>
              Eco-friendly home essentials and décor that bring sustainability into your daily lifestyle.
            </p>
          </div>
        </Link>

        <Link
          to="/accessories-beauty"
          style={{ textDecoration: "none", color: "inherit", display: "block" }}
        >
          <div
            style={{
              background: "rgba(255, 255, 255, 0.1)",
              borderRadius: "20px",
              padding: "30px",
              textAlign: "center",
              backdropFilter: "blur(6px)",
              boxShadow: "0 8px 20px rgba(0, 0, 0, 0.3)",
              transition: "transform 0.3s ease, box-shadow 0.3s ease",
              cursor: "pointer",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "translateY(-10px)";
              e.currentTarget.style.boxShadow = "0 12px 25px rgba(0, 0, 0, 0.5)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "none";
              e.currentTarget.style.boxShadow = "0 8px 20px rgba(0, 0, 0, 0.3)";
            }}
          >
            <img
              src="https://img.freepik.com/free-photo/top-view-frame-with-care-products-wooden-table_23-2148261058.jpg?semt=ais_hybrid&w=740"
              alt="Accessories and Beauty"
              style={{
                width: "100%",
                maxHeight: 180,
                objectFit: "cover",
                borderRadius: 15,
                marginBottom: 15,
              }}
            />
            <h2 style={{ marginBottom: 15, fontSize: "1.8rem" }}>Accessories & Beauty</h2>
            <p style={{ fontSize: "1rem", lineHeight: 1.5 }}>
              Shop natural skincare, eco-accessories, and beauty products that are kind to the planet.
            </p>
          </div>
        </Link>
      </section>
    </div>
  );
}

export default Home;
