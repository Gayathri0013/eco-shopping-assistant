function Orders() {
  return (
    <div style={{
      padding: 20,
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      color: '#333',
      maxWidth: 900,
      margin: 'auto',
    }}>
      <h2>Orders</h2>
      <p>Your orders history will be displayed here.</p>
      {/* You can add an orders list and tracking UI here */}
    </div>
  );
}

export default Orders;
